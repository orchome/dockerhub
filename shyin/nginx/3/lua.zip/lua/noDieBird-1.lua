--自动生成lua防封脚本, 防封等级: 1

--定义参数
local http = ngx.var.scheme.."://"
local args = ngx.req.get_uri_args()
local t = ngx.time()

--引入包
local helper = require "helper"
local md5 = require "md5"

--获取参数key，reids的key
local key, err = args['key'] 
if not key then
	--ngx.say("failed to get key", err)
	return ngx.redirect(helper.weixin110());
end

--获取参数originalUrl，原始链接
local originalUrl, err = args['originalUrl'] 
if not originalUrl then
        --ngx.say("failed to get originalUrl ", err)
        return ngx.redirect(helper.weixin110());
end
originalUrl = helper.urlEncode(originalUrl)

--redis链接
local redis = helper.getRedis(ngx)
if redis == nil then
        ngx.say('redis connect error') 
        return
end

--获取redis对应的key是否存在
local redis_key, err = redis:get(key);
if redis_key==ngx.null then
	--ngx.say("failed to get Key", err)
	return ngx.redirect(helper.weixin110());	
end

--删除上级redis存储key
redis:del(key)

--获取防封中转页面
local html, err = redis:get('no_die_bird');
if html==ngx.null then
        ngx.say("failed to get no_die_bird", err);
        return
end

--判断是否存在下级防封
local _next, err = redis:get('no_die_bird_2');
if _next==ngx.null then
        --ngx.say("failed to get no_die_bird_two", err)
        --return
   
	-----------------------------------没有下级防封，直接跳转落地--------------------------------------

	--转码原始链接
	originalUrl = helper.urlDecode(originalUrl)	
	--处理传参分别获取:原始中转域名, 原始request_uri
	local zz = originalUrl
	local key_i = string.find(originalUrl, '@zz@', 1)
	local originalUri = ''
	if key_i ~= nil then
        	--原始中转域名
	        zz = string.sub(originalUrl, key_i+4)
	        --原始request_uri
        	originalUri = string.sub(originalUrl, 1, key_i-1)
	end

	return helper.jumpLuodi(originalUri, originalUrl, redis_key, zz, redis, ngx);


else

        -----------------------------------存在下级防封, 继续跳转--------------------------------------
        --md5加密，作为redis的key
        local key = md5.sumhexa(_next..originalUrl..t)

        --存储redis 
        redis:set(key, redis_key)
        redis:expire(key, helper.keyExpire())

        local _html = http..t.."."..html
        _next = t..".".._next
        local return_url = _html.."?returnUrl=".._next.."&key="..key.."&originalUrl="..originalUrl

        --关闭redis 
        local ok, err = redis:close()
        if not ok then 
                ngx.say("failed to close redis2:", err)
                return  
        end

        return ngx.redirect(return_url); 

end
