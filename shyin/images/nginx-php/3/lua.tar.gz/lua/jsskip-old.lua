local host = ngx.var.host
local request_uri = ngx.var.request_uri
local http = ngx.var.scheme .. "://";
local final_url = nil
local appid = ngx.var.appid
local key = string.gsub(host, appid..".", '')
local is_beizai = nil

--获取中转域名
host = string.gsub(host, "-", "$$")
local appid_once = string.gsub(appid, "-", "$$")
key =  string.gsub(host, appid_once..".", "")
key =  string.gsub(key, "%$%$", "-")
host = string.gsub(host, "%$%$", "-")


local helper = require "helper"

--request_uri = string.gsub(request_uri, "%?", "#")
--ngx.say("request_uri:", request_uri)

--获取当前时间戳
ngx.update_time()
local time = ngx.time()

--链接redis
local redis = require "resty.redis"
local cache = redis.new()
local ok, err = cache.connect(cache, '10.8.111.182', '6379')
cache:set_timeout(60000)
if not ok then
        ngx.say("failed to connect:", err)
        return
end

--使用密码登录
local count
count, err = cache:get_reused_times()
if 0 == count then
    ok, err = cache:auth("ShiYin-Go2099")
if not ok then
       ngx.say("failed to auth: ", err)
       return
end
elseif err then
    ngx.say("failed to get reused times: ", err)
return
end

--取中转对应的落地域名
local num, err = cache:llen(key)
--ngx.say("redis res len:", num)
math.randomseed(tostring(os.time()):reverse():sub(1, 6))
local random_num = math.random(0, num-1)
--ngx.say("redis res random_num:", random_num)
local res, err = cache:lrange(key, random_num, random_num)
--ngx.say("redis res:", res)
if res == ngx.null then
        ngx.say("key not found.")
        return
end

--如果没有对应的落地域名，取灾备中转域名
if next(res) == nil then
        res, err = cache:lrange("zaibeizhongzhuan", 0, 0)
        is_beizai = "beizai"
end


--域名一个月没使用记录删除
cache:setex("domainCheck:"..key, 2592000, time)

--关闭redis
local ok, err = cache:close()

local luodidomain = http..appid.."."..table.concat(res)..request_uri


if is_beizai == "beizai" then
        if string.find(luodidomain, '?') == nil then
                luodidomain = http..appid.."."..table.concat(res)..request_uri.."?origin_zhongzhuan="..key
        else
                luodidomain = http..appid.."."..table.concat(res)..request_uri.."&origin_zhongzhuan="..key
        end
end

luodidomain = helper.urlEncode(luodidomain)

--拼接新的域名
final_url = http..host.."?paramsyssanli="..luodidomain
 
--ngx.say("final_url:", final_url)

return ngx.redirect(final_url);
