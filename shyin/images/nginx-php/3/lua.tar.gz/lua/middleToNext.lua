--中转跳一级防封

--定义变量
local t = ngx.time()
local host = ngx.var.host
local appid = ngx.var.appid
local http = ngx.var.scheme .. "://";
local request_uri = ngx.var.request_uri

--引入包
local md5 = require "md5"
local helper = require "helper"
                  
--链接redis
local redis = helper.getRedis(ngx)
if redis == nil then
	ngx.say('redis connect error')
	return
end

-- ip防封方式
--ban tencent ips
--helper.banTxIp(redis,ngx)


local zhongzhuan = string.gsub(host, appid..".", '')
--获取中转域名
local _host = string.gsub(host, '-', '$$')
_search = string.gsub(appid, '-', '$$')
_host  = string.gsub(_host, _search..'.', '')
_host = string.gsub(_host, "%$%$", "-")
--域名一个月没使用记录删除
redis:setex("domainCheck:".._host, 2592000, t)

local use_no_die_bird = redis:get('no_die_bird_use');
local no_die_bird_domain_list = redis:get('no_die_bird_domain_list');


------------------------------------------------------------------------------------
---------------------------------- 使用不死鸟防封 ----------------------------------
------------------------------------------------------------------------------------


--开关开启 and 中转域名存在 no_die_bird_domain_list 列表中
if  use_no_die_bird~=ngx.null and
    (use_no_die_bird=='1' or use_no_die_bird==1) and
    no_die_bird_domain_list~=ngx.null and 
    (string.find(no_die_bird_domain_list,'+++'.._host..'+++')~=nil) then

	--获取一级防封域名
	local one, err = redis:get('no_die_bird_1');
	if one==ngx.null then
        	ngx.say("failed to get no_die_bird_1", err)
	        return
	end

	--urlencode转码原始链接
        local originalUrl = helper.urlEncode(request_uri.."@zz@".._host)

	--md5加密，作为redis的key
	local key = md5.sumhexa(one..originalUrl..t)

	--防封页面
	local html, err = redis:get('no_die_bird');
	if html==ngx.null then
        	ngx.say("failed to get no_die_bird", err);
	        return
	end

	--组装参数
	local _html = http..t.."."..html
	local one = t.."."..one
	local return_url = _html.."?returnUrl="..one.."&key="..key.."&originalUrl="..originalUrl

	--存储redis 
	redis:set(key, appid)
	redis:expire(key, helper.keyExpire())

	--关闭redis
	local ok, err = redis:close()
	if not ok then
        	ngx.say("failed to close redis1:", err)
	        return
	end

	return ngx.redirect(return_url);


------------------------------------------------------------------------------------
--------------------------------- getKey.lua的逻辑 ---------------------------------
------------------------------------------------------------------------------------


elseif  use_no_die_bird~=ngx.null and
    (use_no_die_bird=='2' or use_no_die_bird==2) then

        local cache = redis
        local host = ngx.var.host
        local request_uri = ngx.var.request_uri
        local appid = ngx.var.appid
        local key = _host
        local http = ngx.var.scheme .. "://";
        local final_url = nil
        local is_beizai = nil

        --随机取落地域名
	local res = helper.getRandomDomain(cache, ngx, key)

        --如果没有对应的落地域名，取灾备中转域名
        if next(res) == nil then
                res, err = cache:lrange("zaibeizhongzhuan", 0, 0)
                is_beizai = "beizai"
        end


        --关闭redis
        local ok, err = cache:close()
        if not ok then
                ngx.say("failed to close:", err)
                return
        end


        --拼接新的域名
        final_url = helper.getFinalUrl(http, appid, res, key, request_uri)
        return ngx.redirect(final_url);


------------------------------------------------------------------------------------
--------------------------------- jsskip.lua的逻辑 ---------------------------------
------------------------------------------------------------------------------------

else


	    local cache = redis
	    local host = ngx.var.host
        local request_uri = ngx.var.request_uri
        local http = ngx.var.scheme .. "://";
        local final_url = nil
        local appid = ngx.var.appid
        local key = _host
        local is_beizai = nil

        --request_uri = string.gsub(request_uri, "%?", "#")
        --ngx.say("request_uri:", request_uri)

        --获取当前时间戳
        ngx.update_time()
        local time = ngx.time()

        --取中转对应的落地域名
	local res = helper.getRandomDomain(cache, ngx, key)

        --如果没有对应的落地域名，取灾备中转域名
        if next(res) == nil then
                res, err = cache:lrange("zaibeizhongzhuan", 0, 0)
                is_beizai = "beizai"
        end

        -- 查看域名是否被隔离，隔离的话添加人工点击按钮
        local is_geli, err = cache:get('isolationDomain:'..key)


        --关闭redis
        local ok, err = cache:close()

        --拼接新的域名
        final_url = http..host.."?paramsyssanli="..helper.urlEncode(helper.getFinalUrl(http, appid, res, key, request_uri))


	if tonumber(is_geli) == 1 then
   		final_url = final_url.."&is_geli="..1
	end


        --ngx.say("final_url:", final_url)

        return ngx.redirect(final_url);


end
