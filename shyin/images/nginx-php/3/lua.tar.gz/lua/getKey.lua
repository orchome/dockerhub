local host = ngx.var.host
local request_uri = ngx.var.request_uri
local appid = ngx.var.appid
local key = string.gsub(host, appid..".", '')
local http = ngx.var.scheme .. "://";
local final_url = nil
local is_beizai = nil


host = string.gsub(host, "-", "$$")
local appid_once = string.gsub(appid, "-", "$$")
key =  string.gsub(host, appid_once..".", "")
key =  string.gsub(key, "%$%$", "-")

--ngx.say("key:", key)

local redis = require "resty.redis"
local cache = redis.new()
local ok, err = cache.connect(cache, '10.8.111.182', '6379')
cache:set_timeout(60000)
if not ok then
        ngx.say("failed to connect:", err)
        return
end


local count
count, err = cache:get_reused_times()
if 0 == count then
    ok, err = cache:auth("ShiYin-Go2099")
if not ok then
       ngx.say("failed to auth: ", err)
       return
end
elseif err then
    ngx.say("failed to get reused times: ", err)
return
end

--随机取落地域名
local num, err = cache:llen(key)
--ngx.say("redis res len:", num)
math.randomseed(tostring(os.time()):reverse():sub(1, 6))
local random_num = math.random(0, num-1)
--ngx.say("redis res random_num:", random_num)
local res, err = cache:lrange(key, random_num, random_num)
--ngx.say("redis res:", res)
if not res then
        ngx.say("failed to get redis key: ", err)
        return
end


if not res then
        ngx.say("failed to get redis key: ", err)
        return
end

if res == ngx.null then
        ngx.say("key not found.")
        return
end


--如果没有对应的落地域名，取灾备中转域名
if next(res) == nil then
	res, err = cache:lrange("zaibeizhongzhuan", 0, 0)
	is_beizai = "beizai"
end 


--关闭redis
local ok, err = cache:close()
if not ok then
        ngx.say("failed to close:", err)
        return
end


--拼接新的域名
final_url = http..appid.."."..table.concat(res)..request_uri

--如果备灾，备灾域名拼接
if is_beizai == "beizai" then 
	if string.find(final_url, '?') == nil then
		final_url = http..appid.."."..table.concat(res)..request_uri.."?origin_zhongzhuan="..key
	else
		final_url = http..appid.."."..table.concat(res)..request_uri.."&origin_zhongzhuan="..key
	end
end 

--ngx.say("finalurl: ", final_url)

return ngx.redirect(final_url);


