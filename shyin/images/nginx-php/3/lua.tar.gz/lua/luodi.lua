local host = ngx.var.host
local appid = ngx.var.appid
local key = string.gsub(host, appid..".", '')
local helper = require "helper"

--链接redis
local redis = helper.getRedis(ngx)
if redis == nil then
        ngx.say('redis connect error')
        return
end

--ban tencent ips
--helper.banTxIp(redis,ngx)

--获取中转域名
host = string.gsub(host, "-", "$$")
local appid_once = string.gsub(appid, "-", "$$")
key =  string.gsub(host, appid_once..".", "")
key =  string.gsub(key, "%$%$", "-")
--ngx.say("appid", appid)
--ngx.say("key:", key)

-- 获取当前时间错，精确到秒
ngx.update_time()
local time = ngx.time()
--ngx.say("time:", time)

--域名一个月没使用记录删除
redis:setex("domainCheck:"..key, 2592000, time)

--关闭redis
local ok, err = redis:close()

ngx.exit(ngx.OK)
