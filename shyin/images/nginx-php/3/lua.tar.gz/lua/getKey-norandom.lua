local host = ngx.var.host
local request_uri = ngx.var.request_uri
local appid = ngx.var.appid
local key = string.gsub(host, appid..".", '')
local http = ngx.var.scheme .. "://";
local final_url = nil

host = string.gsub(host, "-", "$$")
local appid_once = string.gsub(appid, "-", "$$")
key =  string.gsub(host, appid_once..".", "")

--ngx.say("key:", key)

local redis = require "resty.redis"
local cache = redis.new()
local ok, err = cache.connect(cache, '10.8.111.182', '6379')
cache:set_timeout(60000)
if not ok then
        ngx.say("failed to connect:", err)
        return
end


local count
count, err = cache:get_reused_times()
if 0 == count then
    ok, err = cache:auth("ShiYin-Go2099")
if not ok then
       ngx.say("failed to auth: ", err)
       return
end
elseif err then
    ngx.say("failed to get reused times: ", err)
return
end


local res, err = cache:lrange(key, 0, 0)

--ngx.say("redis res:", res)

if not res then
        ngx.say("failed to get redis key: ", err)
        return
end

if res == ngx.null then
        ngx.say("key not found.")
        return
end

local ok, err = cache:close()

if not ok then
        ngx.say("failed to close:", err)
        return
end


final_url = http..appid.."."..table.concat(res)..request_uri

--ngx.say("finalurl: ", final_url)

return ngx.redirect(final_url);


