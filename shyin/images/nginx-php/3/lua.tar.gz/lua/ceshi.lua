local host = ngx.var.host
local request_uri = ngx.var.request_uri
local http = ngx.var.scheme .. "://";
local final_url = nil
request_uri = string.gsub(request_uri, "%?", "#")

--ngx.say("request_uri:", request_uri)

--拼接新的域名
final_url = http..host.."?paramsyssanli="..request_uri
 
--ngx.say("final_url:", final_url)

return ngx.redirect(final_url);
