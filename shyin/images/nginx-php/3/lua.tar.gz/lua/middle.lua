local host = ngx.var.host
local request_uri = ngx.var.request_uri
local appid = ngx.var.appid
local key = string.gsub(host, appid..".", '')
local http = ngx.var.scheme .. "://";
local final_url = nil
local rtn_url = nil

--ngx.say(ngx.var.urlparam)



--获取中转域名
host = string.gsub(host, "-", "$$")
local appid_once = string.gsub(appid, "-", "$$")
key =  string.gsub(host, appid_once..".", "")
key =  string.gsub(key, "%$%$", "-")
host = string.gsub(host, "%$%$", "-")
--ngx.say("key:", key)

--ngx.say(host)

--链接redis
local redis = require "resty.redis"
local cache = redis.new()
local ok, err = cache.connect(cache, '172.19.185.72', '6379')
cache:set_timeout(60000)
if not ok then
        ngx.say("failed to connect:", err)
        return
end


local count
count, err = cache:get_reused_times()
if 0 == count then
    ok, err = cache:auth("Shiyin2018")
if not ok then
       ngx.say("failed to auth: ", err)
       return
end
elseif err then
    ngx.say("failed to get reused times: ", err)
return
end


--取reids中转对应的落地域名
local res, err = cache:lrange(key, 0, 0)
--ngx.say("redis res:", res)
if not res then
        ngx.say("failed to get redis key: ", err)
        return
end
if res == ngx.null then
        ngx.say("key not found.")
        return
end


--关闭redis
local ok, err = cache:close()
if not ok then
        ngx.say("failed to close:", err)
        return
end

rtn_url = "http://"..appid.."."..table.concat(res)..request_uri
--ngx.say(rtn_url)

--拼接新的域名
final_url = http..host.."?returnurl="..rtn_url

--ngx.say("final_url:", final_url)

return ngx.redirect(final_url);

